#include <stdio.h>
#include <math.h>
#include "entropy.h"

/**
 * Counts the occurrences of all the characters in the file given as the first
 * parameter (the FILE pointer was obtained with the fopen function) and puts
 * all the counts in the counts array.  
 *
 * @param file: A file opened in read mode
 * @param counts: The counts array must be of size 256,
 * and all cells must initially be at 0.
 * @post the `counts` array will contain the number of occurrences of each symbol
 *       (ie. counts[i] contains the number of occurrences of symbol i).
 */
void count_occurrences(FILE *file, int counts[]){
   int c;
   while (((c = fgetc(file)) != '\0') && !feof(file)) {
         counts[c]++;
   }
}

/**
 * Computes the entropy according to the symbol occurrences.
 *
 * @param counts: an array of 256 cells that contains the number of occurrences of each of the
 *        256 bytes.
 * @return a data structure containing the entropy information of the file.
 */
struct file_stat entropy(int counts[]){
   struct file_stat fs;
   int nb = 0,i;
   float en = 0;

   for(i=0; i <256; i++) {
         nb+=counts[i];
         if(counts[i] != 0)
            en+=counts[i]*log2(counts[i]);
   }

   fs.size = nb;
   fs.entropy = log2(nb) - (en/nb);
   return fs;
}
